#include "xz_link.h"

//单向链表尾部添加节点
int xz_insert_node_tail(NODE_H* head, NODE_T* node)
{
    if(head->next == NULL){
        head->next = node;
    }else{
        NODE_T *tmp_node = head->next;
        while(1){
            if(tmp_node->next == NULL){
                tmp_node->next = node;
                break;
            }else {
                tmp_node = tmp_node->next;
            }
        }
    }
    return 0;
}

//销毁链表
void xz_destory_link(NODE_H* head)
{
    if(head->next == NULL){
        printf("the list is empty...\n");
        return;
    }else {
        
        while(1){
            NODE_T *tmp_node = head->next;
            if(tmp_node != NULL){
                head->next = tmp_node->next;
                free(tmp_node);
                tmp_node = NULL;
            }else {
              break;
            }
        }
        free(head);
    }
}


//创建链表栈
LINK_STACK* xz_creat_link_stack()
{

    return NULL;
}

//销毁链表栈
int xz_destory_link_stack(LINK_STACK* stack)
{

    return 0;
}

//入栈
int xz_push_link_stack(LINK_STACK* stack, NODE_T* node)
{

    return 0;
}

//出栈
NODE_T* xz_pop_link_stack(LINK_STACK* stack)
{

    return NULL;
}

//返回栈元素个数
int xz_size_link_stack(LINK_STACK* stack)
{

    return 0;
}
