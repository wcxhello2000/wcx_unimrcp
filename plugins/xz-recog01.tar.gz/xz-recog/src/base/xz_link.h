#ifndef __C_LINK_H__
#define __C_LINK_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct NODE_T{
    char* key;
    char* value;
    struct NODE_T* next;
}NODE_T;

typedef struct NODE_H{
    NODE_T* next;
}NODE_H;

//单向链表尾部添加节点
int xz_insert_node_tail(NODE_H* head, NODE_T* node);

//释放链表
void xz_destory_link(NODE_H* head);

typedef struct LINK_STACK{
    int cur_size;//当前链表栈元素数
    int max_size;//最大链表栈元素数
    NODE_H* head;//链表头
}LINK_STACK;

//创建链表栈
LINK_STACK* xz_creat_link_stack();

//销毁链表栈
int xz_destory_link_stack(LINK_STACK* stack);

//入栈
int xz_push_link_stack(LINK_STACK* stack, NODE_T* node);

//出栈
NODE_T* xz_pop_link_stack(LINK_STACK* stack);

//返回栈元素个数
int xz_size_link_stack(LINK_STACK* stack);

#endif