#include "xz_link.h"

//单向链表尾部添加节点
int xz_insert_node_tail(NODE_H* head, NODE_T* node)
{
    if(head->next == NULL){
        head->next = node;
    }else{
        NODE_T *tmp_node = head->next;
        while(1){
            if(tmp_node->next == NULL){
                tmp_node->next = node;
                break;
            }else {
                tmp_node = tmp_node->next;
            }
        }
    }
    return 0;
}

//销毁链表
void xz_destory_link(NODE_H* head)
{
    if(head->next == NULL){
        printf("the list is empty...\n");
        return;
    }else {
        
        while(1){
            NODE_T *tmp_node = head->next;
            if(tmp_node != NULL){
                head->next = tmp_node->next;
                free(tmp_node);
                tmp_node = NULL;
            }else {
              break;
            }
        }
        free(head);
    }
}

// //打印链表节点信息
// void display_linklist(const NODE_H* head)
// {
//     if(head->next == NULL)
//     {
//         printf("the list is empty...\n");
//         return;
//     }
//     else
//     {
//         NODE_T *tmp_node = head->next;
//         while(1)
//         {
//             if(tmp_node != NULL)
//             {
//                 printf("list:key=%d start=%d end=%d value=%d\n", tmp_node->key, tmp_node->value);
//                 tmp_node = tmp_node->next;
//             }
//             else
//             {
//               break;
//             }
//         }
//     }
// }


