#ifndef __C_LINK_H__
#define __C_LINK_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct NODE_T{
    char* key;
    char* value;
    struct NODE_T* next;
}NODE_T;

typedef struct NODE_H{
    NODE_T* next;
}NODE_H;

//单向链表尾部添加节点
int xz_insert_node_tail(NODE_H* head, NODE_T* node);

//释放链表
void xz_destory_link(NODE_H* head);

//打印链表节点信息
// void display_linklist(const NODE_H* head)

#endif